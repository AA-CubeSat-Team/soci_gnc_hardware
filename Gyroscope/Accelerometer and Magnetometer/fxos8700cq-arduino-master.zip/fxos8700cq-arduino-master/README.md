FXOS8700CQ-Arduino
==================

Arduino library for the Xtrinsic FXOS8700CQ 6-Axis Sensor with Integrated Linear Accelerometer and Magnetometer

# Install

## Recommended
1. Download the github repo
2. Extract the file into your Arduino's library folder
3. Include & Enjoy!

## Command-line
* Navigate to the Arduino library folder
* Clone this github repo into the FXOS8700CQ folder
* Include code into your project and enjoy!

# Usage
To be continued...
